﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ConexionBD.BD
{
    internal class conexion
    {

        public static SqlConnection getConexion()
        {
            string servidor = "CARLOS-BANOL";
            string database = "CURSOPLATZI";
            string user = "Carlos\\Banol";
            string password = "";
            string Isecurity = "true";

            string cadenaConexion = "server=" + servidor + "; database=" + database + "; user=" + user + "; password=" + password + "; integrated security=" + Isecurity;

            SqlConnection conexion = new SqlConnection(cadenaConexion);
            return conexion;
        }
    }
}
