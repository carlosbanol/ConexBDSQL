﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using ConexionBD.BD;

namespace ConexionBD
{
    public partial class Form1 : Form
    {
        SqlConnection conn = conexion.getConexion();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'cURSOPLATZIDataSet.STUDENTS' Puede moverla o quitarla según sea necesario.
            this.sTUDENTSTableAdapter.Fill(this.cURSOPLATZIDataSet.STUDENTS);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string firstname = txtName.Text;
            string lastname = txtLastName.Text;
            string edad = txtAge.Text;
            int age = Convert.ToInt32(edad);
            string email = txtEmail.Text;
            //Abro conexión
            conn.Open();

            string sql = "INSERT INTO STUDENTS VALUES('"
                +firstname+"', '"+lastname+"', '"+age+"', '"+email+"')";
            SqlCommand comando = new SqlCommand(sql, conn);
            comando.ExecuteNonQuery();
            MessageBox.Show("Agregado correctamente");
            conn.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            string email = txtEmail.Text;
            conn.Open();

            string sql = "DELETE FROM STUDENTS WHERE EMAIL ='"+email+"'";
            SqlCommand comando = new SqlCommand(sql, conn);
            comando.ExecuteNonQuery();
            MessageBox.Show("Eliminado correctamente");
            conn.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string firstname = txtName.Text;
            string lastname = txtLastName.Text;
            string email = txtEmail.Text;
            conn.Open();

            string sql = "UPDATE STUDENTS SET FIRSTNAME ='"+firstname+"', LASTNAME = '"+lastname+"' WHERE EMAIL = '"+email+"'";
            SqlCommand comando = new SqlCommand(sql, conn);
            comando.ExecuteNonQuery();
            MessageBox.Show("Actualizado correctamente");
            conn.Close();
        }
    }
    
}
